# Food Delivery App

`React Native` `UI`

<p align="center" flexdirection="coloumn">
<img src='./src/database/images/foodappdetails.png' width="100%">
</p>
 
```

Thanks For Being HERE

```

## Watch Out the Full Video on YouTube

`Video link`

- https://youtu.be/FEujXMl7-D4

## Follow us For more Amazing Videos

`Our Youtube Channel`

- https://www.youtube.com/channel/UC07K1c4xgD6x21Lak4wVuiA

`Github Profile`

- https://github.com/jaydipvidhate
```
